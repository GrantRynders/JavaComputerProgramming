module grantrynders.program5 {
    requires javafx.controls;
    exports grantrynders.program5;
}
